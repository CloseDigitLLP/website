import aboutFeature from '../../styles/aboutUs/aboutFeature.module.scss'
import {
    faClone,
    faLightbulb,
    faClock,
    faUsersViewfinder,
    faChartPie,
    faBox,
    faCog,
    faShieldAlt,
    faLifeRing,
  } from "@fortawesome/free-solid-svg-icons";
  import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'




export default function Services(){
return(
    <section className={`section-spacing`}>
        <div className="section-title-part">
            <p className="back-title">Our Services</p>
            <h5 className="section-title">Our Services</h5>
       </div>
       <div className="container">
        <div className="row justify-content-center">
            <div  className={`${aboutFeature['fadeInUp']} col-lg-4 mb-3 mb-lg-4` }>
                <div className={aboutFeature['card']}>
                    <div className={aboutFeature['card-body']}>
                        <div className={aboutFeature['icon-box']}>
                            <FontAwesomeIcon icon={faLightbulb} />
                        </div>
                        <h3 className={aboutFeature['card-title']}>UI/UX Design</h3>
                    </div>
                </div>
            </div>
            <div  className={`${aboutFeature['fadeInUp']} col-lg-4 mb-3 mb-lg-4` }>
                <div className={aboutFeature['card']}>
                    <div className={aboutFeature['card-body']}>
                        <div className={aboutFeature['icon-box']}>
                            <FontAwesomeIcon icon={faUsersViewfinder} />
                        </div>
                        <h3 className={aboutFeature['card-title']}>Desktop Application</h3>
                    </div>
                </div>
            </div>
            <div  className={`${aboutFeature['fadeInUp']} col-lg-4 mb-3 mb-lg-4` }>
                <div className={aboutFeature['card']}>
                    <div className={aboutFeature['card-body']}>
                        <div className={aboutFeature['icon-box']}>
                            <FontAwesomeIcon icon={faClock} />
                        </div>
                        <h3 className={aboutFeature['card-title']}>Web App Development</h3>
                    </div>
                </div>
            </div>
             <div  className={`${aboutFeature['fadeInUp']} col-lg-4 mb-3 mb-lg-4` }>
                <div className={aboutFeature['card']}>
                    <div className={aboutFeature['card-body']}>
                        <div className={aboutFeature['icon-box']}>
                            <FontAwesomeIcon icon={faClock} />
                        </div>
                        <h3 className={aboutFeature['card-title']}>Mobile App Development</h3>
                    </div>
                </div>
            </div>
              <div  className={`${aboutFeature['fadeInUp']} col-lg-4 mb-3 mb-lg-4` }>
                <div className={aboutFeature['card']}>
                    <div className={aboutFeature['card-body']}>
                        <div className={aboutFeature['icon-box']}>
                            <FontAwesomeIcon icon={faClock} />
                        </div>
                        <h3 className={aboutFeature['card-title']}>Consultancy</h3>
                    </div>
                </div>
            </div>
        </div>
       </div>
       
    </section>
)
}